'use strict'
// index.js
// This is our main server file

// A static server using Node and Express
const express = require("express");

// local modules
const db = require("./sqlWrap");
const win = require("./pickWinner");


// gets data out of HTTP request body 
// and attaches it to the request object
const bodyParser = require('body-parser');


/* might be a useful function when picking random videos */
function getRandomInt(max) {
  let n = Math.floor(Math.random() * max);
  // console.log(n);
  return n;
}


/* start of code run on start-up */
// create object to interface with express
const app = express();

// Code in this section sets up an express pipeline

// print info about incoming HTTP request 
// for debugging
app.use(function(req, res, next) {
  console.log(req.method,req.url);
  next();
})
// make all the files in 'public' available 
app.use(express.static("public"));

// if no file specified, return the main page
app.get("/", (request, response) => {
  response.sendFile(__dirname + "/public/compare.html");
});

// Get JSON out of HTTP request body, JSON.parse, and put object into req.body
app.use(bodyParser.json());

//pick two distict random videos and send an array containing their VideoTable data in the HTTP response
app.get("/getTwoVideos", async function(req, res) {
  //get two distinct numbers
  let index1 = getRandomInt(7);
  let index2 = getRandomInt(7);
  while(index1 == index2){
    index1 = getRandomInt(7);
    index2 = getRandomInt(7);
  }

  let allVideos = await win.getAllVideos();

  //two random videos
  let twoVideos = [];
  twoVideos.push(allVideos[index1]);
  twoVideos.push(allVideos[index2]);
  
  console.log("Sending two random videos", twoVideos);
  res.send(twoVideos);
});

//take an object (sent as JSON) as input, indicating that one video is better than another and store in database
app.post("/insertPref", async function(req, res) {

  let pref = req.body;
  console.log(pref);
  //insert preference to database
  await win.insertPreference(pref.better, pref.worse); 
  let prefList = await win.getAllPrefs();

  console.log("Number of preferences", prefList.length);
  if(prefList.length < 15){
    res.send("continue");
  }
  else{
    res.send("pick winner");
  }
});

app.get("/getWinner", async function(req, res) {
  console.log("getting winner");
  try {
    // winnerRowId should contain the rowId of the winning video.
    let winnerRowId = await win.computeWinner(8, false);
    let winner = await win.getWinnerRow(winnerRowId);
    console.log("Winner is ", winner);
    // send back row of winner
    res.json(winner);
  } catch(err) {
    res.status(500).send(err);
  }
});


// Page not found
app.use(function(req, res){
  res.status(404); 
  res.type('txt'); 
  res.send('404 - File '+req.url+' not found'); 
});

// end of pipeline specification

// Now listen for HTTP requests
// it's an event listener on the server!
const listener = app.listen(3000, function () {
  console.log("The static server is listening on port " + listener.address().port);
});

