let videoElmts = document.getElementsByClassName("tiktokDiv");
let reloadButtons = document.getElementsByClassName("reload");
let heartButtons = document.querySelectorAll("div.heart");
let solidHeart = document.getElementsByClassName("solidHeart");
let nextButton = document.getElementsByClassName("enabledButton").item(0);
let vidName = document.getElementsByClassName("videoName");

let rowIds = []; //rowIds of the two selected videos
let liked; //rowId of liked video
let unliked; //rowId of unliked video

for (let i=0; i<2; i++) {
  let reload = reloadButtons[i]; 
  reload.addEventListener("click",function() { reloadVideo(videoElmts[i]) });
  heartButtons[i].classList.add("unloved");
  heartButtons[i].addEventListener("click", function(){ 
    heartClicked(i); });
  solidHeart[i].style.display = "none";
} // for loop

nextButton.addEventListener("click", nextClicked)
//make next button disabled until liked video
nextButton.disabled = true;
nextButton.className = "disabledButton";

//change heart color when clicked
function heartClicked(clickedIndex){

  for (let i=0; i<2; i++) {
    //only one video can be liked
    if(i == clickedIndex){
      heartButtons[i].style.display = "none";
      solidHeart[i].style.display = "block";
      liked = rowIds[i]; //set liked to clicked button rowIdNum
    }
    else{
      heartButtons[i].style.display = "block";
      solidHeart[i].style.display = "none";
      unliked = rowIds[i]; //unliked is rowIdNum of unliked video
    }
  } 

  //make next button enabled
  nextButton.disabled = false;
  nextButton.className = "enabledButton";
  
}

//send an "/insertPref" request to the Server, showing the user's choice. Second, when the response comes back, reload the page to get two new videos.
function nextClicked(){
  let pref = { better: liked, worse: unliked}; 
  sendPostRequest("/insertPref", pref)
    .then(function(response){
      if(response == "continue"){
        window.location.reload();
      }
      else if(response == "pick winner"){
        window.location = "winner.html";
      }
    })
    .catch( function(err) {
      console.log("Insert preference error: ",err);
    });
    
}

// Get pairs of videos from the server and show videos
async function showVideos() {
  
  let videos = await sendGetRequest("/getTwoVideos");
  
  //store corresponding rowIdNum of the 2 videos in "rowIds" array
  rowIds.push(videos[0].rowIdNum);  
  rowIds.push(videos[1].rowIdNum);

  for (let i=0; i<2; i++) {
    addVideo(videos[i].url,videoElmts[i]);
    vidName.item(i).textContent = videos[i].nickname;
  }
  
  // load the videos after the names are pasted in! 
  loadTheVideos();
}

showVideos();





